package com.ckcelliot.springboot.repository;

import com.ckcelliot.springboot.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Custom Method without null or no result(Optional)
    Optional<Employee> findByEmail(String Email);

    // Define custom query using JPQL with index params
    @Query("select e from Employee e where e.firstName = ?1 and e.lastName = ?2")
    Employee findByJPQL(String firstName, String lastName);

    // Define custom query using JPQL with named params
    @Query("select e from Employee e where e.firstName =:firstName and e.lastName =:lastName")
    Employee findByJPQLNamedParams(@Param("firstName") String firstName, @Param("lastName") String lastName);

    // Define custom query using Native SQL with index params
    @Query(value = "select * from employees e where e.first_Name = ?1 and e.last_Name = ?2", nativeQuery = true)
    Employee findByNativeSQL(String firstName, String lastName);

    // Define custom query using Native SQL with named params
    @Query(value = "select * from employees e where e.first_Name =:firstName and e.last_Name =:lastName", nativeQuery = true)
    Employee findByNativeSQLNamedParams(@Param("firstName") String firstName, @Param("lastName")String lastName);
}

