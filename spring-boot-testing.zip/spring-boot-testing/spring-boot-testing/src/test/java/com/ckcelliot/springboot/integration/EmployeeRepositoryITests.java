package com.ckcelliot.springboot.integration;

import com.ckcelliot.springboot.entity.Employee;
import com.ckcelliot.springboot.repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class EmployeeRepositoryITests extends AbstractionBaseTest {

    @Autowired
    private EmployeeRepository employeeRepository;

    @BeforeEach
    void setup(){
        employeeRepository.deleteAll();
    }

    // Junit test for save employee operation
    @DisplayName("Junit test for save employee operation")
    @Test
    public void givenEmployeeObject_whenSave_thenReturnSavedEmployee(){

        // given - precondition or setup
        Employee employee = Employee.builder()
                .firstName("Elliot")
                .lastName("Cheung")
                .email("elliotcheung@gmail.com")
                .build();

        // when - action or the behaviour that we are going test
        Employee savedEmployee = employeeRepository.save(employee);

        // then - verify the output
        assertThat(savedEmployee).isNotNull();
        assertThat(savedEmployee.getId()).isGreaterThan(0);

    }

    // Junit test for get all employee operation
    @DisplayName("Junit test for get all employee operation")
    @Test
    public void givenEmployeesList_whenFindAll_thenEmployeesList(){

        // given - precondition or setup
        Employee employee = Employee.builder()
                .firstName("Elliot")
                .lastName("Cheung")
                .email("elliotcheung@gmail.com")
                .build();

        Employee employee1 = Employee.builder()
                .firstName("Elliot")
                .lastName("KC")
                .email("elliotcheung1@gmail.com")
                .build();


        employeeRepository.save(employee);
        employeeRepository.save(employee1);

        // when - action or the behaviour that we are going test
        List<Employee> employeeList = employeeRepository.findAll();

        // then - verify the output
        assertThat(employeeList).isNotNull();
        assertThat(employeeList.size()).isEqualTo(2);

    }

    // Junit test for get employee by id operation
    @DisplayName("Junit test for get employee by id operation")
    @Test
    public void givenEmployeeObject_whenFindByObject_thenReturnEmployeeObject() {

        // given - precondition or setup
        Employee employee = Employee.builder()
                .firstName("Elliot")
                .lastName("Cheung")
                .email("elliotcheung@gmail.com")
                .build();

        employeeRepository.save(employee);

        // when - action or the behaviour that we are going test
        Employee employeeDB = employeeRepository.findById(employee.getId()).get();

        // then - verify the output
        assertThat(employeeDB).isNotNull();

    }

    // Junit test for get employee by email operation
    @DisplayName("Junit test for get employee by email operation")
    @Test
    public void givenEmployeeEmail_whenFindByEmail_thenReturnEmployeeObject() {

        // given - precondition or setup
        Employee employee = Employee.builder()
                .firstName("Elliot")
                .lastName("Cheung")
                .email("elliotcheung@gmail.com")
                .build();

        employeeRepository.save(employee);

        // when - action or the behaviour that we are going test
        Employee employeeDB = employeeRepository.findByEmail(employee.getEmail()).get();

        // then - verify the output
        assertThat(employeeDB).isNotNull();

    }

    // Junit test for update employee operation
    @DisplayName("Junit test for update employee operation")
    @Test
    public void givenEmployeeObject_whenUpdateEmployee_thenReturnUpdatedEmployee() {

        // given - precondition or setup
        Employee employee = Employee.builder()
                .firstName("Elliot")
                .lastName("Cheung")
                .email("elliotcheung@gmail.com")
                .build();

        employeeRepository.save(employee);

        // when - action or the behaviour that we are going test
        Employee savedEmployee = employeeRepository.findById(employee.getId()).get();
        savedEmployee.setEmail("elliotcheung1@gmail.com");
        savedEmployee.setFirstName("Elliott");
        Employee updatedEmployee = employeeRepository.save(savedEmployee);

        // then - verify the output
        assertThat(updatedEmployee.getEmail()).isEqualTo("elliotcheung1@gmail.com");
        assertThat(updatedEmployee.getFirstName()).isEqualTo("Elliott");

    }

    // Junit test for delete employee operation
    @DisplayName("Junit test for delete employee operation")
    @Test
    public void givenEmployeeObject_whenDelete_thenRemoveEmployee() {

        // given - precondition or setup
        Employee employee = Employee.builder()
                .firstName("Elliot")
                .lastName("Cheung")
                .email("elliotcheung@gmail.com")
                .build();

        Employee employee1 = Employee.builder()
                .firstName("Elliot")
                .lastName("KC")
                .email("elliotcheung1@gmail.com")
                .build();


        employeeRepository.save(employee);
        employeeRepository.save(employee1);

        // when - action or the behaviour that we are going test
        employeeRepository.delete(employee);
        employeeRepository.deleteById(employee1.getId());
        Optional <Employee> employeeOptional = employeeRepository.findById(employee.getId());
        Optional <Employee> employeeOptional1 = employeeRepository.findById(employee1.getId());

        // then - verify the output
        assertThat(employeeOptional).isEmpty();
        assertThat(employeeOptional1).isEmpty();

    }

    // Junit test for custom query using JPQL with index
    @DisplayName("Junit test for custom query using JPQL with index")
    @Test
    public void givenFirstNameAndLastName_whenFindByJPQL_thenReturnEmployeeObject() {

        // given - precondition or setup
        Employee employee = Employee.builder()
                .firstName("Elliot")
                .lastName("Cheung")
                .email("elliotcheung@gmail.com")
                .build();

        employeeRepository.save(employee);
        String firstName = "Elliot";
        String lastName = "Cheung";

        // when - action or the behaviour that we are going test
        Employee savedEmployee = employeeRepository.findByJPQL(firstName, lastName);

        // then - verify the output
        assertThat(savedEmployee).isNotNull();

    }

    // Junit test for custom query using JPQL with Named params
    @DisplayName("Junit test for custom query using JPQL with Named params")
    @Test
    public void givenFirstNameAndLastName_whenFindByJPQLNamedParams_thenReturnEmployeeObject() {

        // given - precondition or setup
        Employee employee = Employee.builder()
                .firstName("Elliot")
                .lastName("Cheung")
                .email("elliotcheung@gmail.com")
                .build();

        employeeRepository.save(employee);
        String firstName = "Elliot";
        String lastName = "Cheung";

        // when - action or the behaviour that we are going test
        Employee savedEmployee = employeeRepository.findByJPQLNamedParams(firstName, lastName);

        // then - verify the output
        assertThat(savedEmployee).isNotNull();

    }

    // Junit test for custom query using Native SQL with index
    @DisplayName("Junit test for custom query using Native SQL with index")
    @Test
    public void givenFirstNameAndLastName_whenFindByNativeSQL_thenReturnEmployeeObject() {

        // given - precondition or setup
        Employee employee = Employee.builder()
                .firstName("Elliot")
                .lastName("Cheung")
                .email("elliotcheung@gmail.com")
                .build();

        employeeRepository.save(employee);
        //String firstName = "Elliot";
        //String lastName = "Cheung";

        // when - action or the behaviour that we are going test
        Employee savedEmployee = employeeRepository.findByNativeSQL(employee.getFirstName(), employee.getLastName());

        // then - verify the output
        assertThat(savedEmployee).isNotNull();

    }

    // Junit test for custom query using Native SQL with Named params
    @DisplayName("Junit test for custom query using Native SQL with Named params")
    @Test
    public void givenFirstNameAndLastName_whenFindByNativeSQLNamedParams_thenReturnEmployeeObject() {

        // given - precondition or setup
        Employee employee = Employee.builder()
                .firstName("Elliot")
                .lastName("Cheung")
                .email("elliotcheung@gmail.com")
                .build();

        employeeRepository.save(employee);
        //String firstName = "Elliot";
        //String lastName = "Cheung";

        // when - action or the behaviour that we are going test
        Employee savedEmployee = employeeRepository.findByNativeSQLNamedParams(employee.getFirstName(), employee.getLastName());

        // then - verify the output
        assertThat(savedEmployee).isNotNull();

    }

}
